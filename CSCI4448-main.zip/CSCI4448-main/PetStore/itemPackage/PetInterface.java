package itemPackage;

public interface PetInterface {
    public void setPetInfo();
}