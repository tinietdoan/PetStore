package itemPackage;

import java.io.*;

public class generalAddOn extends addOn {
    public generalAddOn(){
        descript = "general";
    }
    public double extraCost(){
        return 0.0;
    }
}
