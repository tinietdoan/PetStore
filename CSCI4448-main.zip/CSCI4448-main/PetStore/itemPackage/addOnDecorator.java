package itemPackage;

import java.io.*;

// part of Decorator Pattern
public abstract class addOnDecorator extends addOn {
    public abstract String getDescript();
}