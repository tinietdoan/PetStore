package employeePackage;

import java.io.*;
import java.util.*;

public class Clerk extends Employee{

    public Clerk(String name){
        super(name);
    }
}