package employeePackage;

import itemPackage.*;

public interface TrainType {
    public void train(Pet animal);
}