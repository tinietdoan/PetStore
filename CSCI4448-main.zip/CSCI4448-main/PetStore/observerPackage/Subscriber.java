package observerPackage;

public interface Subscriber {
    public void update(Object o);
    public void display();
}
