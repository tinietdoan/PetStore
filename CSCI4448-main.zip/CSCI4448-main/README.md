# CSCI4448
- For the class CSCI4448 (OOAD)

- This is the general repository for students Tinie Doan and Wyett Considine

- Java version:
  -java version "11.0.14" 2022-01-18 LTS

## PetStore Directory
- Projects 2, 3, and 4 can be found in this directory. Each project shares the same source code but have separate outputs and deliverabeles for submission, which can be found in their respective folders.

- This project is a Pet Store simulation. It involves employees, animals, store inventory, and the basics of running a store.

## SemesterProject Directory
- Projects 5, 6, 7 can be found in this directory. Each project shares the same source code but have separate outputs and deliverabeles for submission, which can be found in their respective folders.

- RUNNING INSTRUCTIONS:
  - Compile from the /SemesterProject Directory using 'javac *.java'
  - Run the game using 'java main'

- Our semester project centers around a text-based farming game called Happy Go Farming. It is a highscore-based game where players will attempt to get as many Gold Stars (points) as they can in a given time frame. The game will involve:
  - farming: watering plants, harvesting plants, etc.
  - interacting with friends: talking, delegating tasks, etc.
  - maintaining the player's environment: buying supplies, selling seeds, etc.
  
  
  
