package Actions;

import java.io.*;
import java.util.*;
import Friends.*;

public interface actionType {
    public void doAction(Friend f);
    public String toString();
}
